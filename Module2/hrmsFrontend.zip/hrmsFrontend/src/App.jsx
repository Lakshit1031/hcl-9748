import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
import SampleCode from './assets/Component/SampleCode'
import UseFetchApi from './assets/Component/UseFetchApi'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Home } from './assets/Component/Home'
import { Dashboard } from './assets/Component/Dashboard'
import Login from './assets/Component/Login'
import { Registration } from './assets/Component/Registration'

function App() {

  return (
    <>
      <div>
        <BrowserRouter>
        <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/dashboard' element={<Dashboard/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/register' element={<Registration/>}/>

        </Routes>
        </BrowserRouter>
        {/* <SampleCode /> */}
        {/* <UseFetchApi /> */}
      </div>
    </>
  )
}

export default App
