
package com.abes.hrmsdatabase.service;

import com.abes.hrmsdatabase.model.Attendance;
import com.abes.hrmsdatabase.repository.AttendanceRepository;
import com.abes.hrmsdatabase.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AttendenceService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private AttendanceRepository attendanceRepository;

    public String markAttendance(Attendance attendance) {

        if (attendance.getEmployee() == null) {
            return "Employee is required";
        }

        long empId = attendance.getEmployee().getEmp_id();

        if (!employeeRepository.existsById(empId)) {
            return "Employee not found";
        }

        if (attendanceRepository
                .existsByEmployee_Emp_idAndAttendanceDate(
                        empId, attendance.getAttendanceDate())) {
            return "Attendance already marked for this date";
        }

        attendanceRepository.save(attendance);

        return "Attendance marked successfully";
    }
}
